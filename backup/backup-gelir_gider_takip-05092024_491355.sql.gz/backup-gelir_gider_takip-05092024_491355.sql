CREATE DATABASE IF NOT EXISTS `gelir_gider_takip`;

USE `gelir_gider_takip`;

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` enum('income','expense') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `categories` VALUES("1","Market","expense","2024-08-08 15:33:59");
INSERT INTO `categories` VALUES("2","Maaş","income","2024-08-08 15:34:08");
INSERT INTO `categories` VALUES("3","Alışveriş","expense","2024-08-08 15:37:29");
INSERT INTO `categories` VALUES("4","Benzin","expense","2024-08-08 15:37:35");
INSERT INTO `categories` VALUES("5","Harçlık","income","2024-08-08 15:37:48");



DROP TABLE IF EXISTS `expense`;

CREATE TABLE `expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `category` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `month` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `expense` VALUES("1","2024-08-02","Dizüstü Bilgisayar","abur cubur","50.00","August");
INSERT INTO `expense` VALUES("2","2024-08-09","Market","abur cubur","100.00","August");
INSERT INTO `expense` VALUES("3","2024-08-14","Alışveriş","yemek","1089.00","August");
INSERT INTO `expense` VALUES("4","2024-08-18","Benzin","yakıt alındı 30 litre","2400.00","August");
INSERT INTO `expense` VALUES("5","2024-08-13","Market","asdasdas","400.00","August");
INSERT INTO `expense` VALUES("6","2024-08-26","Alışveriş","adsfdsafdsafadsf","320.00","August");
INSERT INTO `expense` VALUES("7","2024-08-06","Benzin","abur cuburasdf","100.00","August");
INSERT INTO `expense` VALUES("8","2024-05-01","Market","abur cubur","240.00","May");
INSERT INTO `expense` VALUES("9","2024-08-18","Benzin","yakıt alındı 30 litre","2400.00","August");
INSERT INTO `expense` VALUES("10","2024-07-11","Alışveriş","asdfdasf","450.00","July");
INSERT INTO `expense` VALUES("11","2024-07-02","Alışveriş","abur cubur","100.00","July");
INSERT INTO `expense` VALUES("12","2024-09-03","Market","asdfdsafdsaf","100.00","September");
INSERT INTO `expense` VALUES("13","2024-09-03","Market","asdfdsafdsaf","10000.00","September");



DROP TABLE IF EXISTS `income`;

CREATE TABLE `income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `category` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `month` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `income` VALUES("1","2024-08-06","Maaş","Maaş yatırımı","20000.00","August");
INSERT INTO `income` VALUES("2","2024-08-06","Maaş","abur cubur","50.05","August");
INSERT INTO `income` VALUES("3","2024-08-02","Market","asdasdas","100.98","August");
INSERT INTO `income` VALUES("4","2024-08-02","Maaş","asdasdas","100.98","August");
INSERT INTO `income` VALUES("5","2024-08-01","Maaş","Maaş aldım","10.00","August");
INSERT INTO `income` VALUES("6","2024-08-04","Maaş","adfasd","24.00","August");
INSERT INTO `income` VALUES("7","2024-08-04","Maaş","maaş alındı","20.00","August");
INSERT INTO `income` VALUES("8","2024-08-09","Maaş","aaaa","2000.00","August");
INSERT INTO `income` VALUES("9","2024-08-08","Maaş","maaş almak","20000.98","August");
INSERT INTO `income` VALUES("10","2024-08-16","Maaş","deneme yeni sistem oldu artık","40000.00","August");



DROP TABLE IF EXISTS `smtp_settings`;

CREATE TABLE `smtp_settings` (
  `ID` int(11) NOT NULL,
  `smtphost` varchar(255) DEFAULT NULL,
  `smtpuser` varchar(255) DEFAULT NULL,
  `smtppassword` text DEFAULT NULL,
  `smtpport` varchar(10) DEFAULT NULL,
  `smtpgonderen` varchar(255) DEFAULT NULL,
  `last_updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `smtp_settings` VALUES("1","smtp.gmail.com","denemeburda99@gmail.com","TE9wUTV5SlU5RXVjelNTYWNtZ2pHZz09Ojrv+9Eoo9pTWxY4US4wtGz+","587","Balaban Web","admin");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_photo` varchar(255) DEFAULT 'path/to/default/profile.jpg',
  `son_giris` datetime DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `users` VALUES("1","admin","Eyüp Can","Balaban","denemeburda99@gmail.com","$2y$10$dv5s5230/SClWtBrjtdjSO6qZzdiw6QYROgWQ0OO2zWVFYEAu7yLi","Yönetici","2024-08-12 12:11:35","profiles/ben.jpg","2024-09-03 12:09:35","Aktif");
INSERT INTO `users` VALUES("3","denemeburda99","deneme","burda","denemeburda991@gmail.com","$2y$10$OLYXXyDRP3zJMNKErljNj.ayFF3WBdadHIMGP4yZU5tbPA4Ww0d4G","Üye","2024-09-04 08:34:48","path/to/default/profile.jpg",NULL,"Aktif");
